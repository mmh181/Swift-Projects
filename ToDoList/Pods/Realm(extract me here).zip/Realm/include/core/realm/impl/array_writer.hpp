/*************************************************************************
 *
 * Copyright 2016 Realm Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 **************************************************************************/

#ifndef REALM_ARRAY_WRITER_HPP
#define REALM_ARRAY_WRITER_HPP

#include <realm/alloc.hpp>

namespace realm {
namespace _impl {

class ArrayWriterBase {
public:
    virtual ~ArrayWriterBase()
    {
    }

    /// Write the specified array data and its checksum into free
    /// space.
    ///
    /// Returns the ref (position in the target stream) of the written copy of
    /// the specified array data.
    virtual ref_type write_array(const char* data, size_t size, uint32_t checksum) = 0;
};

} // namespace impl_
} // namespace realm

#endif // REALM_ARRAY_WRITER_HPP
